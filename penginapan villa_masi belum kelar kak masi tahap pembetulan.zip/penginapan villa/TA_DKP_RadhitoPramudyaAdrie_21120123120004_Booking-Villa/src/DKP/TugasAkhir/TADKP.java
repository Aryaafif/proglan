
package DKP.TugasAkhir;

public class TADKP {

    public static void main(String[] args) {
        new LoginBooking().setVisible(true);
        
    }
    
}
