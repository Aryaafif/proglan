package DKP.TugasAkhir;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class LoginBooking extends javax.swing.JFrame {

    public LoginBooking() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtPassword = new javax.swing.JPasswordField();
        txtUsername = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(44, 62, 80));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 12));
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));

        jButton1.setBackground(new java.awt.Color(255, 165, 0));
        jButton1.setFont(new java.awt.Font("Modern No. 20", 1, 18));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Login");
        jButton1.addActionListener(evt -> loginActionPerformed());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Gambar/Halaman Login.png")));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(130, 130, 130)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtUsername, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
                                        .addComponent(txtPassword))
                                .addContainerGap(50, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(165, 165, 165))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(70, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void loginActionPerformed() {
        String username = txtUsername.getText().trim();
        String password = String.valueOf(txtPassword.getPassword()).trim();

        if (username.equals("admin") && password.equals("Zaki100")) {
            new HalamanBooking().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Username atau password salah", "Login Gagal", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new LoginBooking().setVisible(true));
    }

    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsername;
}

class HalamanBooking extends javax.swing.JFrame {

    private javax.swing.JComboBox<String> Cbtype;
    private javax.swing.JTextField txtTanggal;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTable jTable1;
    private javax.swing.JSpinner jSpinner1;

    public HalamanBooking() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        txtTanggal = new javax.swing.JTextField();
        txtHarga = new javax.swing.JTextField();
        Cbtype = new javax.swing.JComboBox<>();
        jSpinner1 = new javax.swing.JSpinner();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Cbtype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"Pilih Tipe Villa", "Villa 1", "Villa 2", "Big Villa"}));
        Cbtype.addActionListener(evt -> updateHarga());

        txtHarga.setEditable(false);

        jTable1.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"Tipe Villa", "Tanggal Check-in", "Jumlah Hari", "Harga", "Total Harga"}
        ));

        javax.swing.JButton btnPesan = new javax.swing.JButton("Pesan");
        btnPesan.addActionListener(evt -> tambahPesanan());

        javax.swing.JButton btnBayar = new javax.swing.JButton("Bayar");
        btnBayar.addActionListener(evt -> bayarPesanan());

        // Layout setup code (not included for brevity)
    }

    private void updateHarga() {
        String tipe = (String) Cbtype.getSelectedItem();
        if (tipe != null) {
            switch (tipe) {
                case "Villa 1":
                    txtHarga.setText("1200000");
                    break;
                case "Villa 2":
                    txtHarga.setText("1800000");
                    break;
                case "Big Villa":
                    txtHarga.setText("2500000");
                    break;
                default:
                    txtHarga.setText("");
                    break;
            }
        }
    }

    private void tambahPesanan() {
        String tipe = (String) Cbtype.getSelectedItem();
        String tanggal = txtTanggal.getText();
        int jumlahHari = (int) jSpinner1.getValue();
        int harga = Integer.parseInt(txtHarga.getText());
        int total = harga * jumlahHari;

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.addRow(new Object[]{tipe, tanggal, jumlahHari, harga, total});
    }

    private void bayarPesanan() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int rowCount = model.getRowCount();
        int totalBayar = 0;

        for (int i = 0; i < rowCount; i++) {
            totalBayar += (int) model.getValueAt(i, 4);
        }

        JOptionPane.showMessageDialog(this, "Total pembayaran: Rp " + NumberFormat.getInstance().format(totalBayar), "Pembayaran", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new HalamanBooking().setVisible(true));
    }
}
