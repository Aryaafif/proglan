package DKP.TugasAkhir;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class HomeBooking extends JFrame {

    public HomeBooking() {
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        JButton detailButton1 = new JButton("Detail 1");
        JButton detailButton2 = new JButton("Detail 2");
        JButton detailButton3 = new JButton("Detail 3");
        JButton bookingButton = new JButton("Booking");
        JLabel backgroundLabel = new JLabel(new ImageIcon(getClass().getResource("/Gambar/HomeBooking.png")));

        // Action Listeners
        detailButton1.addActionListener(this::showDetail1);
        detailButton2.addActionListener(this::showDetail2);
        detailButton3.addActionListener(this::showDetail3);
        bookingButton.addActionListener(this::openBookingPage);

        // Layout
        mainPanel.setLayout(null);
        mainPanel.add(detailButton1);
        mainPanel.add(detailButton2);
        mainPanel.add(detailButton3);
        mainPanel.add(bookingButton);
        mainPanel.add(backgroundLabel);

        // Set bounds
        detailButton1.setBounds(150, 500, 120, 40);
        detailButton2.setBounds(370, 500, 120, 40);
        detailButton3.setBounds(590, 500, 120, 40);
        bookingButton.setBounds(840, 30, 160, 60);
        backgroundLabel.setBounds(0, 0, 1050, 620);

        // Frame settings
        setContentPane(mainPanel);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1060, 620);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void showDetail1(ActionEvent evt) {
        JFrame detailFrame1 = new JFrame();
        detailFrame1.setSize(1020, 550);
        detailFrame1.add(new JLabel(new ImageIcon(getClass().getResource("/Gambar/Villa1-3.jpeg"))));
        detailFrame1.setVisible(true);
    }

    private void showDetail2(ActionEvent evt) {
        JFrame detailFrame2 = new JFrame();
        detailFrame2.setSize(1020, 550);
        detailFrame2.add(new JLabel(new ImageIcon(getClass().getResource("/Gambar/VillaBig.jpeg"))));
        detailFrame2.setVisible(true);
    }

    private void showDetail3(ActionEvent evt) {
        JFrame detailFrame3 = new JFrame();
        detailFrame3.setSize(1020, 550);
        detailFrame3.add(new JLabel(new ImageIcon(getClass().getResource("/Gambar/VillaA-B.jpeg"))));
        detailFrame3.setVisible(true);
    }

    private void openBookingPage(ActionEvent evt) {
        new DKP.TugasAkhir.FormBooking().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HomeBooking::new);
    }
}
