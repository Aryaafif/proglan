package DKP.TugasAkhir;

public class TADKP {
    public static void main(String[] args) {
        new DKP.TugasAkhir.HomeBooking().setVisible(true);
    }
}
