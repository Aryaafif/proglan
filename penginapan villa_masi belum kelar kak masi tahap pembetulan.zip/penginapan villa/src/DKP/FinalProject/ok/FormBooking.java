package DKP.TugasAkhir;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FormBooking extends JFrame {

    private JTable bookingTable;
    private JTextField totalField;

    public FormBooking() {
        initComponents();
    }

    private void initComponents() {
        JLabel nameLabel = new JLabel("Nama:");
        JLabel phoneLabel = new JLabel("Telepon:");
        JLabel totalLabel = new JLabel("Total:");
        totalField = new JTextField();
        bookingTable = new JTable(new DefaultTableModel(
                new Object[][]{}, new String[]{"Type Villa", "Tanggal Check-in", "Jumlah Hari", "Harga", "Sub Total"}));
        JScrollPane tableScrollPane = new JScrollPane(bookingTable);
        JButton payButton = new JButton("Bayar");

        // Layout
        setLayout(null);
        nameLabel.setBounds(30, 30, 100, 30);
        phoneLabel.setBounds(30, 70, 100, 30);
        tableScrollPane.setBounds(30, 120, 500, 200);
        totalLabel.setBounds(350, 340, 50, 30);
        totalField.setBounds(400, 340, 130, 30);
        payButton.setBounds(200, 400, 100, 40);

        add(nameLabel);
        add(phoneLabel);
        add(tableScrollPane);
        add(totalLabel);
        add(totalField);
        add(payButton);

        payButton.addActionListener(e -> processPayment());

        // Frame settings
        setTitle("Form Booking");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void processPayment() {
        DefaultTableModel model = (DefaultTableModel) bookingTable.getModel();
        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk diproses!");
            return;
        }

        try {
            double total = Double.parseDouble(totalField.getText());
            String input = JOptionPane.showInputDialog(this, "Total pembayaran: " + total + "\nMasukkan jumlah uang:");
            if (input == null || input.isEmpty()) return;

            double payment = Double.parseDouble(input);
            if (payment < total) {
                JOptionPane.showMessageDialog(this, "Jumlah pembayaran tidak mencukupi!");
            } else {
                JOptionPane.showMessageDialog(this, "Pembayaran berhasil! Kembalian: " + (payment - total));
                model.setRowCount(0);
                totalField.setText("");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Input tidak valid!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(FormBooking::new);
    }
}