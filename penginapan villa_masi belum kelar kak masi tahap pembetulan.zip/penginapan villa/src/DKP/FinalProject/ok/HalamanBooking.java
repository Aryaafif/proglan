package DKP.FinalProject.ok;

import javax.swing.*;

public class HalamanBooking extends javax.swing.JFrame {
    private String customerName;
    private String phoneNumber;
    private String price;

    public HalamanBooking() {
        initComponents();
    }

    public void setCustomerData(String name, String phone) {
        this.customerName = name;
        this.phoneNumber = phone;
        customerNameLabel.setText(name);
        phoneLabel.setText(phone);
    }

    public HalamanBooking(String[] rowData) {
        initComponents();
    }

    public JTable getBookingTable() {
        return bookingTable;
    }

    public JTextField getTotalTextField() {
        return totalTextField;
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        titleLabel = new javax.swing.JLabel();
        tableScrollPane = new javax.swing.JScrollPane();
        bookingTable = new JTable();
        totalTextField = new JTextField();
        totalLabel = new javax.swing.JLabel();
        customerNameLabel = new javax.swing.JLabel();
        phoneLabel = new javax.swing.JLabel();
        backgroundLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(500, 600));
        setResizable(false);
        getContentPane().setLayout(null);

        getContentPane().add(titleLabel);
        titleLabel.setBounds(475, 64, 17, 328);

        bookingTable.setModel(new javax.swing.table.DefaultTableModel(
                new Object [][] {},
                new String [] {
                        "Villa Type", "Check-in Date", "Days", "Price", "Subtotal"
                }
        ));
        tableScrollPane.setViewportView(bookingTable);
        getContentPane().add(tableScrollPane);
        tableScrollPane.setBounds(30, 240, 453, 158);

        getContentPane().add(totalTextField);
        totalTextField.setBounds(355, 410, 120, 28);

        totalLabel.setFont(new java.awt.Font("Courier New", 3, 14));
        totalLabel.setText("Total");
        getContentPane().add(totalLabel);
        totalLabel.setBounds(300, 420, 50, 20);

        customerNameLabel.setFont(new java.awt.Font("Verdana", 1, 14));
        customerNameLabel.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(customerNameLabel);
        customerNameLabel.setBounds(90, 141, 208, 30);

        phoneLabel.setFont(new java.awt.Font("Mongolian Baiti", 1, 14));
        getContentPane().add(phoneLabel);
        phoneLabel.setBounds(110, 183, 208, 30);

        backgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/invoice_background.png")));
        getContentPane().add(backgroundLabel);
        backgroundLabel.setBounds(0, 0, 500, 600);

        pack();
        setLocationRelativeTo(null);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HalamanBooking().setVisible(true);
            }
        });
    }

    private javax.swing.JLabel titleLabel;
    private javax.swing.JLabel totalLabel;
    private javax.swing.JLabel customerNameLabel;
    private javax.swing.JLabel phoneLabel;
    private javax.swing.JLabel backgroundLabel;
    private javax.swing.JScrollPane tableScrollPane;
    private JTable bookingTable;
    private JTextField totalTextField;
}
